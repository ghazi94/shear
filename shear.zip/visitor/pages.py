def pages():
    pages = [
        {
            'context' : '1 seater sofa',
            'url' : 'https://www.gozefo.com/ncr/category/sofas/one-seater'
        },
        {
            'context': '2 seater sofa',
            'url': 'https://www.gozefo.com/ncr/category/sofas/two-seater'
        },
        {
            'context': '3 seater sofa',
            'url': 'https://www.gozefo.com/ncr/category/sofas/three-seater'
        },
        {
            'context': 'Sofa sets',
            'url': 'https://www.gozefo.com/ncr/category/sofas/sofa-sets'
        },
        {
            'context': 'L shaped sofa',
            'url': 'https://www.gozefo.com/ncr/category/sofas/l-shape-sofa'
        },
        {
            'context': 'Sofa Cum Beds',
            'url': 'https://www.gozefo.com/ncr/category/sofas/sofa-cum-beds'
        },
        {
            'context': 'Recliners',
            'url': 'https://www.gozefo.com/ncr/category/sofas/recliners'
        }
    ]
    return pages